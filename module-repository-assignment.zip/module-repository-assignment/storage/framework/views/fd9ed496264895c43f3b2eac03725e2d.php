<?php echo e($slot); ?>

<?php /**PATH /home/hacker/arbaz/module-repository-assignment/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>