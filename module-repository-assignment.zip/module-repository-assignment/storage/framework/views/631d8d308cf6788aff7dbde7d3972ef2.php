<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h1 class="mb-4">Modules</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <a href="<?php echo e(route('modules.create')); ?>" class="btn btn-primary mb-3">Add Module</a>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <table class="table table-bordered table-striped">
                <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>Module Name</th>
                        <th>Lecturer Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($module->id); ?></td>
                            <td><?php echo e($module->module_name); ?></td>
                            <td><?php echo e($module->lecturer_name); ?></td>
                            <td>
                                <a href="<?php echo e(route('modules.edit', $module)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <form action="<?php echo e(route('modules.destroy', $module)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hacker/arbaz/module-repository-assignment/resources/views/modules/index.blade.php ENDPATH**/ ?>