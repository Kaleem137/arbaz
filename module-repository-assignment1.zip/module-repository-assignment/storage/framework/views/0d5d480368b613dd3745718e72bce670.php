<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Module</h1>
    <form action="<?php echo e(route('modules.update', $module)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="form-group">
            <label for="module_name">Module Name</label>
            <input type="text" name="module_name" id="module_name" class="form-control" value="<?php echo e($module->module_name); ?>" required>
        </div>
        <div class="form-group">
            <label for="lecturer_name">Lecturer Name</label>
            <input type="text" name="lecturer_name" id="lecturer_name" class="form-control" value="<?php echo e($module->lecturer_name); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Module</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hacker/arbaz/arbaz/module-repository-assignment/resources/views/modules/edit.blade.php ENDPATH**/ ?>