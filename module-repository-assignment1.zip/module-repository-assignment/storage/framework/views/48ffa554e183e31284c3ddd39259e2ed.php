"You are not authorized to access this page."
<?php /**PATH /home/hacker/arbaz/arbaz/module-repository-assignment/resources/views/errors/not-authorized.blade.php ENDPATH**/ ?>