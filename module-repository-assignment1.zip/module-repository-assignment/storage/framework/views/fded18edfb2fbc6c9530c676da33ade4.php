<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Module Repository Tool')); ?></title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name', 'Module Repository Tool')); ?></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link<?php echo e(Route::currentRouteName() === 'modules.index' ? ' active' : ''); ?>" href="<?php echo e(route('modules.index')); ?>">Modules</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link<?php echo e(Route::currentRouteName() === 'profile.edit' ? ' active' : ''); ?>" href="<?php echo e(route('profile.edit')); ?>">Profile</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                Logout
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container mt-4">
            <?php if(auth()->guard()->check()): ?>
                <div class="row">
                    <div class="col">
                        <?php
                            $user = Auth::user();
                            $role = $user->role;
                        ?>
                        <h4>Welcome <?php echo e($user->name); ?>!</h4>
                        <?php if($role === App\Models\User::ROLE_ADMIN): ?>
                            <p>Role: Admin</p>
                        <?php elseif($role === App\Models\User::ROLE_LECTURER): ?>
                            <p>Role: Lecturer</p>
                        <?php elseif($role === App\Models\User::ROLE_STUDENT): ?>
                            <p>Role: Student</p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <script>
            window.addEventListener('DOMContentLoaded', function () {
                var alertElements = document.querySelectorAll('.alert');
                alertElements.forEach(function (element) {
                    element.addEventListener('click', function () {
                        element.style.display = 'none';
                    });
                });
            });
        </script>

        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
        <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/hacker/arbaz/arbaz/module-repository-assignment/resources/views/layouts/app.blade.php ENDPATH**/ ?>